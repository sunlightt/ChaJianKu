# 更新日志

## LArea1.72 - 修改于2016年6月12日
* GC少量优化，css少量优化

## LArea1.71 - 修改于2016年4月26日
* 修复BUG:Cannot read property 'textContent' of undefined

## LArea1.7 - 修改于2016年4月15日
* 改善了插件的样式，重新优化了缓动体验，使选中更加流畅

## LArea1.6 - 修改于2016年4月6日
* 改善了插件的样式，修复了城市个数不足导致报错的bug，（感谢网友[song-yuan](https://github.com/song-yuan)提供bug）

## LArea1.5 - 修改于2016年3月17日
* 初始化过程完善，增加type、valueTo、keys属性，具体用法参见首页说明

## LArea1.4 - 修改于2016年3月2日
* 仿IOS原生样式调整插件UI风格

## LArea - 修改于2016年3月2日
* 为了防止l和I混淆，统一将插件名称更改为`LArea`
* 修复LArea和LCalendar插件同时使用时存在的样式异常

## lArea - 修改于2016年2月18日
* 修复滑动过程中可能存在省份显示到市区上的bug
